repo: frankhatfellaaiagent-del/Taxdeed
branch: main

## Last sync
date: 2026-08-11T21:02:30Z

### Updated in this project
- Repo is empty (README only); designed the dashboard fresh against the Industry design system
- Built "Tax Deed Dashboard.dc.html" — 5 screens (dashboard, property detail, lists, scrape history, settings)

## Screen map
| Project screen | Repo files |
| --- | --- |
| Tax Deed Dashboard.dc.html (all screens) | — (no source yet; see CLAUDE-CODE-HANDOFF.md for wiring points) |
